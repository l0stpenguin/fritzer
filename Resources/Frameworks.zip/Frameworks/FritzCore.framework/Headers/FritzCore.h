//
//  FritzCore.h
//  FritzCore
//
//  Created by Christopher Kelly on 6/11/18.
//  Copyright © 2018 Fritz Labs Incorporated. All rights reserved.
//

@import Foundation;
@import CoreML;
@import UIKit;
FOUNDATION_EXPORT double FritzCoreVersionNumber;
FOUNDATION_EXPORT const unsigned char FritzCoreVersionString[];
