//
//  FritzManagedModel.h
//  FritzManagedModel
//
//  Created by Andrew Barba on 8/9/17.
//  Copyright © 2017 Fritz Labs Incorporated. All rights reserved.
//

@import Foundation;

@import FritzCore;

#import <FritzManagedModel/RNCryptor.h>

FOUNDATION_EXPORT double FritzVersionNumber;
FOUNDATION_EXPORT const unsigned char FritzVersionString[];
