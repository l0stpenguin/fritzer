//
//  FritzVisionPeopleSegmentationModel.h
//  FritzVisionPeopleSegmentationModel
//
//  Created by Christopher Kelly on 9/24/18.
//  Copyright © 2018 Fritz Labs Incorporated. All rights reserved.
//

@import FritzVision;

//! Project version number for FritzVisionPeopleSegmentationModel.
FOUNDATION_EXPORT double FritzVisionPeopleSegmentationModelVersionNumber;

//! Project version string for FritzVisionPeopleSegmentationModel.
FOUNDATION_EXPORT const unsigned char FritzVisionPeopleSegmentationModelVersionString[];


