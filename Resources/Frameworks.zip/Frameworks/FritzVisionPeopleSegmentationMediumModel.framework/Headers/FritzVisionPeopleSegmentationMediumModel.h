//
//  FritzVisionPeopleSegmentationMediumModel.h
//  FritzVisionPeopleSegmentationMediumModel.h
//
//  Created by Eric Hsiao on 12/6/18.
//  Copyright © 2018 Fritz Labs Incorporated. All rights reserved.
//

@import FritzVision;

//! Project version number for FritzVisionPeopleSegmentationMediumModel.
FOUNDATION_EXPORT double FritzVisionPeopleSegmentationMediumModelVersionNumber;

//! Project version string for FritzVisionPeopleSegmentationMediumModel.
FOUNDATION_EXPORT const unsigned char FritzVisionPeopleSegmentationMediumModelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FritzVisionPeopleSegmentationMediumModel/PublicHeader.h>


